#!/bin/bash
# DinariBlockchain startup script for Oracle Cloud

# Install Python dependencies
pip3 install -r requirements.txt || pip install -r requirements.txt

# Create directories
mkdir -p blockchain_data logs wallets

# Set permissions
chmod +x app.py

# Start blockchain
echo "🚀 Starting DinariBlockchain..."
python3 app.py
